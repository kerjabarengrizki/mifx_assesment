package amazon.web.create

import amazon.web.utility.CustomTestObject as CustomObject

import internal.GlobalVariable

public class CreatePath {

	public static final YOURNAME_FIELD = CustomObject.getCSSTestObject("#ap_customer_name")
	public static final PHONENUMBER_FIELD = CustomObject.getCSSTestObject("#ap_email")
	public static final PASSWORD_FIELD = CustomObject.getCSSTestObject("#ap_password")
	public static final CONFIRM_PASSWORD_FIELD = CustomObject.getCSSTestObject("#ap_password_check")
	public static final CONTINUE_BUTTON = CustomObject.getCSSTestObject("#continue")
	public static final SELECT_COUNTRY = CustomObject.getXpathTestObject("//span[.='ID +62']")
	public static final VERIFY_MOBILE_NUMBER = CustomObject.getCSSTestObject("#createAccountSubmit")
	public static final NAVIGATION_OPEN = CustomObject.getCSSTestObject("#nav-link-accountList")
	public static final OTP_FIELD = CustomObject.getCSSTestObject("#auth-pv-enter-code")
	public static final CREATE_ACCOUNT_BUTTON = CustomObject.getCSSTestObject("#auth-verify-button")
	
}


