package amazon.web.utility

import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObject
import amazon.web.utility.CustomTestObject.SelectorType


import internal.GlobalVariable

public class CustomTestObject {

		enum SelectorType {
		XPATH("xpath"),
		CSS("css"),
		ATTRIBUTE("attribute"),
		NAME("name")

		String value;

		public SelectorType(String value) {
			this.value = value
		}
	}

	public static TestObject getNameTestObject(String selectorValue) {
		return getTestObject(SelectorType.NAME, selectorValue)
	}

	public static TestObject getXpathTestObject(String selectorValue) {
		return getTestObject(SelectorType.XPATH, selectorValue)
	}

	public static TestObject getCSSTestObject(String selectorValue){
		return getTestObject(SelectorType.CSS, selectorValue)
	}

	private static TestObject getTestObject(SelectorType selectorType, String selectorValue) {
		TestObject to = new TestObject()
		to.addProperty(selectorType.value, ConditionType.EQUALS, selectorValue)
		return to
	}
	
}


